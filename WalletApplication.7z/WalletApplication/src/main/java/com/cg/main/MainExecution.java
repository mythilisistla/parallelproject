package com.cg.main;

import java.util.List;
import java.util.Map;
import java.util.Scanner;

import com.cg.beans.Account;
import com.cg.beans.Customer;
import com.cg.beans.Transaction;
import com.cg.exception.WalletApplicationException;
import com.cg.service.IWalletService;
import com.cg.service.WalletServiceImpl;

public class MainExecution {
	static IWalletService iWalletService;
	public static int customersId;
	public static void main(String[] args) throws WalletApplicationException {
		Scanner scanner = new Scanner(System.in);
		 IWalletService iWalletService = new WalletServiceImpl();
		System.out.println("1.Create account 2.Login");
		int option = scanner.nextInt();
		
		switch(option) {
		case 1:{
			System.out.println("Enter your name");
			String customerName = scanner.next();
			System.out.println("Enter your Date of birth");
			String dateOfBirth = scanner.next();
			System.out.println("Enter phone number");
			String phone  = scanner.next();
			System.out.println("Enter email");
			String email  = scanner.next();
			System.out.println("Enter address");
			String address  = scanner.next();
			int customerId = (int) (Math.random()*1000); 
			
			int accountNo = (int) (Math.random()*100000); 
			double balance = 0.0;
			Account account = new Account(accountNo,balance);
			
			Customer customer = new Customer(customerId,customerName,dateOfBirth,phone,email,address);
			customer.setAccount(account);
			Customer createdCustomer = iWalletService.createAccount(customer);
		
			System.out.println("Account created succesfully!! Your  customer id is "+customerId);
			String o = null;
			customersId = customer.getCustomerId();
			do {
			System.out.println("1.show balance\n2.deposit\n3.withdraw\n4.fundtransfer\n5.printtransaction");
			int opt = scanner.nextInt();
			switch(opt) {
			case 1:{
				System.out.println("enter customer id");
				int custId = scanner.nextInt();
				System.out.println("Your balance is "+iWalletService.showBalance(custId));
			}break;
			case 2:{
				System.out.println("enter your customer id and amount you want to deposit");
				int custId = scanner.nextInt();
				double amount = scanner.nextDouble();
				if(iWalletService.deposit(custId, amount))
						System.out.println("amount deposited successfully");
				else 
					System.out.println("error occured");
			}break;
			case 3:{
				System.out.println("enter your customer id and amount you want to withdraw");
				int custId = scanner.nextInt();
				double amount = scanner.nextDouble();
				if(iWalletService.withdraw(custId, amount)) {
					System.out.println("amount withdrawed succesfully");
				}
			}break;
			case 4:{
				System.out.println("Enter benificiary cutomer id and amount you want to transfer");
				int custId = scanner.nextInt();
				double amount = scanner.nextDouble();
				iWalletService.fundTransfer(custId, amount);
				
			}break;
			case 5:{
				System.out.println("Enter customer id");
				int custId = scanner.nextInt();
				List<Transaction> transationList =iWalletService.printTransaction(custId);
			    for(Transaction transaction:transationList) {
			    	if(transaction.getTransactionType().equals("fund transfered"))
			    		System.out.println("Amount "+transaction.getAmount() +" " +transaction.getTransactionType()+" to customerId"+transaction.getToAccountNo()+" with transaction id "+transaction.getTransactionId()+" at "+transaction.getTransactionDate());
			    	else
			    	System.out.println("Amount "+transaction.getAmount() +" " +transaction.getTransactionType()+" with transaction id "+transaction.getTransactionId()+" at "+transaction.getTransactionDate());
			    }
			}
			}
			System.out.println("Press y to continue");
			o = scanner.next();
			}while(o.equalsIgnoreCase("y"));
			System.out.println("Thank You");
			
		}break;
		case 2:{
			//implementation for login
		}
		}

		scanner.close();
	}

}

