package com.cg.util;

import java.util.HashMap;
import java.util.Map;

import com.cg.beans.Account;
import com.cg.beans.Customer;

public class WalletUtility {
	public static Map<Integer, Customer> customerMap = new HashMap<>();
	static
	{
	   customerMap.put(123,new Customer(123,"Mythili","05/12/1997","9642576081","mythili.sistla@gmail.com","Hyderabad"));
	
	}


}
