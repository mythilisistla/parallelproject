package com.cg.exception;

public class WalletApplicationException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
String str="";
	public WalletApplicationException(String str) {
	super();
	this.str = str;
	
}
	public WalletApplicationException() {
		super();
}
	@Override
	public String getMessage() {
		// TODO Auto-generated method stub
		return str;
	}

	
}
