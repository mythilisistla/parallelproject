package com.cg.beans;

public class Transaction {
	int transactionId ;
	String transactionType;
	String transactionDate;
	int toAccountNo;
	double amount;
	
public Transaction() {
	super();
	// TODO Auto-generated constructor stub
}
	public int getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}
	public String getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	public String getTransactionDate() {
		return transactionDate;
	}
	public void setTransactionDate(String transactionDate) {
		this.transactionDate = transactionDate;
	}
	public int getToAccountNo() {
		return toAccountNo;
	}
	public void setToAccountNo(int toAccountNo) {
		this.toAccountNo = toAccountNo;
	}
	
	
	
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	
	

public Transaction(int transactionId2, String transactiontype, String transactiondate, int toacountno, double amount2) {
		// TODO Auto-generated constructor stub
	this.transactionId = transactionId2;
	this.transactionType = transactiontype;
	this.transactionDate = transactiondate;
	this.toAccountNo = toacountno;
	this.amount = amount;
	}
@Override
public String toString() {
	return "Transaction [transactionId=" + transactionId + ", transactionType=" + transactionType
			+ ", transactionDate=" + transactionDate + ", toAccountNo=" + toAccountNo + ", amount=" + amount + "]";
}
}

