package com.cg.service;

import java.util.List;
import java.util.Map;

import com.cg.beans.Customer;
import com.cg.beans.Transaction;
import com.cg.exception.WalletApplicationException;

public interface IWalletService {
	
	public Customer createAccount (Customer customer) throws WalletApplicationException;
	public double showBalance(int customerId) throws WalletApplicationException;
	public boolean deposit(int customerId, double amount) throws WalletApplicationException;
	public boolean withdraw(int customerId ,double amount)throws WalletApplicationException;
	public boolean fundTransfer(int customerId, double amount)throws WalletApplicationException;
	List<Transaction> printTransaction(int customerId)throws WalletApplicationException;

}
